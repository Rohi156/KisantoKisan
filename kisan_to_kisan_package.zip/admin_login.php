<?php
session_start();
$pdo = new PDO("mysql:host=localhost;dbname=kisan_to_kisan", "root", "");
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
    $stmt->execute([$username, $password]);
    $admin = $stmt->fetch();

    if ($admin) {
        $_SESSION["admin"] = $admin["username"];
        header("Location: admin_add_product.php");
        exit;
    } else {
        $error = "Invalid login!";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Admin Login</title><link rel="stylesheet" href="style.css"></head>
<body>
  <div class="container">
    <h2>Admin Login</h2>
    <form method="post">
      <label>Username:</label>
      <input type="text" name="username" required>
      <label>Password:</label>
      <input type="password" name="password" required>
      <button type="submit">Login</button>
      <p style="color:red"><?= $error ?></p>
    </form>
  </div>
</body>
</html>
