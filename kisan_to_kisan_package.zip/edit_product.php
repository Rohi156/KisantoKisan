<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit;
}
$pdo = new PDO("mysql:host=localhost;dbname=kisan_to_kisan", "root", "");
$id = $_GET["id"];
$product = $pdo->query("SELECT * FROM products WHERE id = $id")->fetch();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $description = $_POST["description"];
    $price = $_POST["price"];
    $contact_number = $_POST["contact_number"];

    $stmt = $pdo->prepare("UPDATE products SET name = ?, description = ?, price = ?, contact_number = ? WHERE id = ?");
    $stmt->execute([$name, $description, $price, $contact_number, $id]);
    header("Location: admin_add_product.php");
}
?>

<!DOCTYPE html>
<html>
<head><title>Edit Product</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Edit Product</h2>
<form method="post">
  <label>Name:</label>
  <input type="text" name="name" value="<?= $product['name'] ?>" required>
  <label>Description:</label>
  <textarea name="description" required><?= $product['description'] ?></textarea>
  <label>Price:</label>
  <input type="number" name="price" value="<?= $product['price'] ?>" required>
  <label>Contact Number:</label>
  <input type="text" name="contact_number" value="<?= $product['contact_number'] ?>" required>
  <button type="submit">Update Product</button>
</form>
</div>
</body>
</html>
