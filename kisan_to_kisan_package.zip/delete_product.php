<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit;
}
$pdo = new PDO("mysql:host=localhost;dbname=kisan_to_kisan", "root", "");
$id = $_GET["id"];
$stmt = $pdo->prepare("SELECT image_url FROM products WHERE id = ?");
$stmt->execute([$id]);
$image_url = $stmt->fetchColumn();
if ($image_url && file_exists($image_url)) {
    unlink($image_url);
}
$stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
$stmt->execute([$id]);
header("Location: admin_add_product.php");
exit;
