<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit;
}
$pdo = new PDO("mysql:host=localhost;dbname=kisan_to_kisan", "root", "");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $description = $_POST["description"];
    $price = $_POST["price"];
    $contact_number = $_POST["contact_number"];
    $image_path = "";

    if ($_FILES["image"]["name"]) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir);
        $image_path = $target_dir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $image_path);
    }

    $stmt = $pdo->prepare("INSERT INTO products (name, description, price, contact_number, image_url, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$name, $description, $price, $contact_number, $image_path]);
}
$products = $pdo->query("SELECT * FROM products ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head><title>Admin - Add Product</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
<h2>Add New Product</h2>
<form method="post" enctype="multipart/form-data">
  <label>Name:</label>
  <input type="text" name="name" required>
  <label>Description:</label>
  <textarea name="description" required></textarea>
  <label>Price:</label>
  <input type="number" name="price" required>
  <label>Contact Number:</label>
  <input type="text" name="contact_number" required>
  <label>Image:</label>
  <input type="file" name="image">
  <button type="submit">Add Product</button>
</form>
<a href="logout.php">Logout</a>

<h3>Existing Products</h3>
<table border="1">
<tr><th>Image</th><th>Name</th><th>Price</th><th>Actions</th></tr>
<?php foreach ($products as $product): ?>
<tr>
  <td><img src="<?= $product['image_url'] ?>" height="60"></td>
  <td><?= $product['name'] ?></td>
  <td><?= $product['price'] ?></td>
  <td>
    <a href="edit_product.php?id=<?= $product['id'] ?>">Edit</a> |
    <a href="delete_product.php?id=<?= $product['id'] ?>" onclick="return confirm('Delete this product?');">Delete</a>
  </td>
</tr>
<?php endforeach; ?>
</table>
</div>
</body>
</html>
